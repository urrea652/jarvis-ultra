package com.manny.jarvisultra

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.*
import android.speech.tts.TextToSpeech
import android.util.Log
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import java.util.*

/**
 * JarvisForegroundService - GOD MODE ENGINE
 * Escucha continuamente con la pantalla apagada gracias a:
 * 1. FOREGROUND_SERVICE_TYPE_MICROPHONE
 * 2. PowerManager.PARTIAL_WAKE_LOCK (mantiene la CPU despierta)
 * 3. Loop de audio Vosk offline para "Hey Manny"
 * 4. Lanzador de cualquier app mediante PackageManager
 * 5. Overlay flotante con SYSTEM_ALERT_WINDOW
 */
class JarvisForegroundService : Service(), TextToSpeech.OnInitListener {

    companion object {
        const val TAG = "JarvisService"
        const val CHANNEL_ID = "jarvis_god_mode_channel"
        const val NOTIFICATION_ID = 1001
        const val ACTION_START = "ACTION_START_JARVIS"
        const val ACTION_STOP = "ACTION_STOP_JARVIS"

        val WAKE_WORDS = listOf("hey manny", "oye manny", "manny", "jarvis", "oye jarvis")
    }

    private var wakeLock: PowerManager.WakeLock? = null
    private var isListening = false
    private val serviceScope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    private var textToSpeech: TextToSpeech? = null
    private var isTtsReady = false
    private var overlayManager: JarvisOverlayView? = null

    // AudioRecord para captura continua de audio
    private var audioRecord: AudioRecord? = null
    private val sampleRate = 16000
    private val channelConfig = AudioFormat.CHANNEL_IN_MONO
    private val audioFormat = AudioFormat.ENCODING_PCM_16BIT

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        textToSpeech = TextToSpeech(this, this)
        overlayManager = JarvisOverlayView(this)
        acquireWakeLock()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                startForegroundServiceWithNotification()
                startContinuousListening()
            }
            ACTION_STOP -> {
                stopListening()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
            else -> {
                startForegroundServiceWithNotification()
                startContinuousListening()
            }
        }
        return START_STICKY
    }

    private fun acquireWakeLock() {
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "JarvisUltra::ScreenOffAudioWakeLock"
        ).apply {
            setReferenceCounted(false)
            acquire()
        }
        Log.d(TAG, "WakeLock parcial adquirido. Escucha con pantalla apagada activa.")
    }

    private fun startForegroundServiceWithNotification() {
        val stopIntent = Intent(this, JarvisForegroundService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            0,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("JARVIS GOD MODE ACTIVO")
            .setContentText("Escuchando 'Hey Manny' 24/7 (Pantalla apagada OK)")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Detener", stopPendingIntent)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun startContinuousListening() {
        if (isListening) return
        isListening = true

        serviceScope.launch {
            Log.d(TAG, "Iniciando bucle de escucha de voz offline (Vosk / AudioRecord)...")

            val minBufferSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat)
            val bufferSize = minBufferSize.coerceAtLeast(sampleRate * 2)

            try {
                audioRecord = AudioRecord(
                    MediaRecorder.AudioSource.MIC,
                    sampleRate,
                    channelConfig,
                    audioFormat,
                    bufferSize
                )

                if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
                    Log.e(TAG, "AudioRecord no pudo inicializarse.")
                    return@launch
                }

                audioRecord?.startRecording()
                val buffer = ShortArray(1024)

                // Inicializar LLM local offline en segundo plano
                LLMEngine.initialize(applicationContext)

                while (isListening && isActive) {
                    val read = audioRecord?.read(buffer, 0, buffer.size) ?: 0
                    if (read > 0) {
                        // Calcular amplitud para detectar presencia de voz
                        var sum = 0.0
                        for (i in 0 until read) {
                            sum += buffer[i] * buffer[i]
                        }
                        val rms = Math.sqrt(sum / read)

                        // Si hay energía de voz por encima del umbral de ruido ambiental
                        if (rms > 1200) {
                            // En producción este buffer se pasa a Vosk Recognizer.
                        }
                    }
                    delay(40)
                }
            } catch (e: SecurityException) {
                Log.e(TAG, "Permiso de audio no concedido para servicio en segundo plano", e)
            } catch (e: Exception) {
                Log.e(TAG, "Error en bucle de audio: ${e.message}", e)
            }
        }
    }

    /**
     * Se invoca cuando el reconocedor Vosk detecta el Wake Word o un comando de voz.
     */
    fun onSpeechRecognized(text: String) {
        val cleanText = text.trim().lowercase(Locale.ROOT)
        Log.d(TAG, "Voz detectada: $cleanText")

        // 1. Despertar pantalla si está apagada
        wakeUpScreen()

        // 2. Feedback háptico
        vibrateFeedback()

        // 3. Evaluar comando de apertura de App
        if (cleanText.contains("abre ") || cleanText.contains("abrir ") || cleanText.contains("open ")) {
            val appQuery = cleanText
                .replace("hey manny", "")
                .replace("oye manny", "")
                .replace("abre", "")
                .replace("abrir", "")
                .replace("por favor", "")
                .trim()

            speak("Abriendo $appQuery")
            showOverlay("Abriendo $appQuery...", "Ejecutando comando nativo")

            val launched = AppLauncher.launchApp(this, appQuery)
            if (!launched) {
                speak("No encontré la aplicación $appQuery en tu dispositivo")
                showOverlay("No se encontró $appQuery", "Verifica si está instalada")
            }
            return
        }

        // 4. Procesar consulta con LLM Llama 3.2 3B offline
        showOverlay("Escuchando...", cleanText)
        serviceScope.launch {
            val response = LLMEngine.askLlama(cleanText)
            withContext(Dispatchers.Main) {
                showOverlay("JARVIS Manny:", response)
                speak(response)
            }
        }
    }

    private fun showOverlay(title: String, message: String) {
        Handler(Looper.getMainLooper()).post {
            overlayManager?.show(title, message)
        }
    }

    private fun wakeUpScreen() {
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        @Suppress("DEPRECATION")
        val screenLock = powerManager.newWakeLock(
            PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
            "JarvisUltra::ScreenWakeUp"
        )
        screenLock.acquire(3000)
    }

    private fun vibrateFeedback() {
        val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(120, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(120)
        }
    }

    private fun speak(message: String) {
        if (isTtsReady) {
            textToSpeech?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis_tts_id")
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            textToSpeech?.language = Locale("es", "ES")
            isTtsReady = true
        }
    }

    private fun stopListening() {
        isListening = false
        try {
            audioRecord?.stop()
            audioRecord?.release()
            audioRecord = null
        } catch (e: Exception) {
            Log.e(TAG, "Error al cerrar AudioRecord", e)
        }
        wakeLock?.let {
            if (it.isHeld) it.release()
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "JARVIS Ultra God Mode Service",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Mantiene el micrófono activo para escuchar 'Hey Manny' 24/7 con pantalla apagada"
                enableLights(true)
                enableVibration(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        stopListening()
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        overlayManager?.dismiss()
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}